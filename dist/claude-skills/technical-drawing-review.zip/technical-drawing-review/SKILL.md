---
name: technical-drawing-review
description: Review a technical drawing for title block, views, flat pattern, dimensions, tolerances, notes and revision, classifying findings Error/Risk/Suggestion. Use for teknik resim kontrolü, antet, ölçülendirme, genel tolerans.
---
# Technical Drawing Review
## Review order
1. Identity, revision, material, scale, units.
2. Views, sections, details, manufacturing-critical geometry.
3. Dimensions and references; missing, duplicate, or conflicting dimensions.
4. General and specific tolerances.
5. GD&T and datum scheme when present or required.
6. Surface finish, weld symbols, bend notes, hardware, manufacturing notes.
7. Title block and revision traceability.
8. Consistency with the stated manufacturing process.
## Rules
- Do not claim a dimension exists if it is not visible or supplied.
- Separate observation from recommendation.
- If a standard is needed, identify the standard question instead of inventing a requirement.
- Do not redesign silently; report the issue and reason.

## Knowledge to load
Reference files are bundled in `references/`.
- `references/06-technical-drawing.md`
- `references/07-gdt-and-tolerancing.md`
- `references/standards-map.md`

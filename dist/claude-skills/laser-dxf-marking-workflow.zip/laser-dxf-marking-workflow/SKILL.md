---
name: laser-dxf-marking-workflow
description: Prepare laser DXF with separated cut, marking/engraving and bend layers (stud positions, part IDs). Use for lazer kesim DXF, işaretleme, gravür, saplama konumu.
---
# Laser DXF and Marking Workflow
## Trigger
Use for laser-cut DXF, engraving/marking geometry, or geometry that must appear in DXF without being cut.
## Workflow
1. Classify geometry as CUT, MARK, REFERENCE, or OTHER.
2. Determine how the receiving laser/CAM distinguishes processes: layers, colors, entities, or machine convention.
3. Never assume a sketch entity is automatically a marking instruction.
4. For SolidWorks, give export/layer guidance only when supported by version or supplied evidence.
5. Check duplicates, scale, units, and separation of process geometry.
6. Require final confirmation in the actual CAM/laser software before production.
## Critical rule
DXF visibility alone does not prove cutting versus marking; the receiving CAM workflow determines process interpretation.

## Knowledge to load
Reference files are bundled in `references/`.
- `references/03-solidworks-sheet-metal.md`
- `references/01-sheet-metal-fundamentals.md`
- `references/09-cad-engineering-practice.md`

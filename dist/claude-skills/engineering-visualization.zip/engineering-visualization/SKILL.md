---
name: engineering-visualization
description: Create engineering visuals (assemblies, sections, process diagrams, concept renders) with explicit invariants such as geometry, counts, proportions and views. Use for mühendislik görseli, teknik illüstrasyon, montaj/akış görseli, render promptu.
---

# Engineering Visualization

## Senaryolar
- sketch → product visualization
- CAD screenshot → realistic product visualization
- technical drawing → explanatory illustration
- sheet-metal enclosure → product render
- assembly → exploded/marketing illustration

## Öncelik
1. Geometrik sadakat
2. Kullanıcının belirttiği teknik özellikler
3. Kompozisyon
4. Malzeme/ışık/render kalitesi

Görsel üretim, gerçek ölçü veya üretilebilirlik doğrulamasının yerine geçmez.

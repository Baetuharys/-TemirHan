---
name: sealing-detail-review
description: Review gasket paths, compression, corners, seams, latches, cable entries and drainage against an enclosure ingress target.
---
# Sealing Detail Review

## Trigger
Use for door sealing, gasket compression, leakage paths or IP-target design questions.

## Workflow
1. Draw/describe one closed seal boundary.
2. List every seam, corner, opening and hardware penetration.
3. Use supplier gasket compression/environment data rather than a guessed universal value.
4. Check door/frame stiffness and latch distribution.
5. Separate design review from IP conformity; specify prototype/test evidence.

## Knowledge to load
- `references/24-sealing-gaskets-and-ingress-details.md`
- `references/05-enclosures-ip-ik.md`
- `design_patterns/enclosures/door-gasket-path.md`

## Output discipline
- Label supplied, calculated, source-backed, assumed, estimated and unknown information.
- Do not invent manufacturer, shop or certification values.
- End with the smallest useful next verification/action.

---
name: solidworks-turkish-ui
description: Give SolidWorks steps for a Turkish interface using verified (V), common (C) or unverified (U) labels and never inventing menu names. Use for SolidWorks Türkçe arayüz, komut adı, menü yolu, terim doğrulama.
---
# SolidWorks Turkish UI Guidance
## Workflow
1. Identify Part, Sheet Metal, Assembly, Drawing, or other workspace.
2. Give the Turkish UI path first.
3. Add the English command name only for disambiguation.
4. Mark version-dependent labels instead of inventing them.
5. Treat screenshots as primary evidence when supplied.
6. Give the shortest actionable sequence plus a verification check.
## Rules
- Never fabricate Turkish labels.
- Do not silently switch to an English-interface workflow.
- Distinguish command, PropertyManager field, feature-tree item, and document property.

## Knowledge to load
Reference files are bundled in `references/`.
- `references/04-solidworks-turkish-ui-and-terminology.md`
- `references/solidworks-ui-labels.csv` (V/C/U label levels)
- `references/glossary-sacmetal.md`

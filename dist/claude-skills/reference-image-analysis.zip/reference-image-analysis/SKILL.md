---
name: reference-image-analysis
description: Analyse reference images for geometry, scale and invariants before visual generation or measurement. Use for referans görsel analizi, ölçek/oran çıkarma.
---

# Reference Image Analysis

## Referans rolleri
- Target: üzerinde düzenleme yapılacak görsel
- Geometry: biçim/oran referansı
- Style: görsel dil, malzeme veya render karakteri
- Composition: yerleşim ve kadraj
- Material: yüzey/doku
- Text/Logo: korunacak marka veya yazı

## Kural
Bir referansın rolü belirtilmeden ondan bütün özellikleri kopyalamış gibi sonuç çıkarılmaz.

## Çıktı
Her referans için: rol, kullanılacak özellikler, korunacak özellikler, belirsizlikler.

## Knowledge to load
Reference files are bundled in `references/`.
- `references/08-image-dimension-estimation.md`

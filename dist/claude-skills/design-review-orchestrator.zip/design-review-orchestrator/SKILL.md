---
name: design-review-orchestrator
description: Route a mechanical design review across requirements, CAD, sheet metal, enclosure/IP, drawing/GD&T, manufacturing, cost and release checks, then consolidate blockers and next actions.
---
# Design Review Orchestrator

## Trigger
Use for broad “review this design” requests, release readiness, or when several domains interact.

## Workflow
1. Run engineering task intake and identify applicable domains.
2. Create a review matrix with requirement/function/process/release columns.
3. Route only relevant specialist skills; avoid loading everything.
4. Consolidate duplicate findings and preserve evidence labels.
5. Separate blockers, warnings, optimizations and optional ideas.
6. End with release state and ordered closure actions.

## Knowledge to load
- `references/21-requirements-risk-and-release.md`
- `references/16-design-troubleshooting-and-decision-support.md`

## Output discipline
- Distinguish facts, calculations, practice, assumptions, estimates and unknowns.
- Do not upgrade a draft analysis into a certification or release claim.
- Prefer a concrete next action over generic advice.

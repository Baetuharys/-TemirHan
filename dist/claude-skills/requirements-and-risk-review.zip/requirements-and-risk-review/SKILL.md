---
name: requirements-and-risk-review
description: Turn vague design goals into traceable, testable requirements; maintain assumption and lightweight risk registers; connect design changes to verification and release artifacts.
---
# Requirements and Risk Review

## Trigger
Use at project start, before release, or after a major design change when requirements/assumptions are unclear.

## Workflow
1. Extract requirements and assign stable IDs.
2. For each requirement capture source, priority and verification method.
3. Record ASSUMED/ESTIMATED/UNKNOWN items in an assumption register.
4. Identify failure modes and closure actions without inventing a company risk score.
5. Trace design changes to CAD/drawing/DXF/BOM/cost/test/document impacts.
6. Return open items that prevent release.

## Knowledge to load
- `references/21-requirements-risk-and-release.md`

## Output discipline
- Distinguish facts, calculations, practice, assumptions, estimates and unknowns.
- Do not upgrade a draft analysis into a certification or release claim.
- Prefer a concrete next action over generic advice.

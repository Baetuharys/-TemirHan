---
name: sheet-metal-bend-analysis
description: Analyse bends: bend allowance, bend deduction, K-factor, flat length, press-brake feasibility (V-die, minimum flange, springback). Use for büküm hesabı, bükme payı, K faktörü, kenar boyu, abkant uygunluğu.
---
# Sheet Metal Bend Analysis
## Trigger
Use for bend feasibility, bend allowance, K-factor, bend deduction, radius, or manufacturability questions.
## Workflow
1. Extract material, thickness, inside radius, angle, flange lengths, bend direction, and process.
2. Separate supplied values from inferred values; never invent K-factor, tooling, or material data.
3. Identify whether the task is geometric, manufacturing, SolidWorks-specific, or combined.
4. Calculate only when required inputs are available.
5. Check units and dimensional plausibility.
6. Check flange/edge distances, hole-to-bend relations, collision, sequence, and tooling access when applicable.
7. Report missing inputs and the next concrete action.
## Rules
- Label exact values and estimates separately.
- Flag values dependent on tooling, temper, machine, or shop practice.
- Distinguish engineering calculations from SolidWorks settings.

## Knowledge to load
Reference files are bundled in `references/`.
- `references/02-bending-and-flat-pattern.md`
- `references/01-sheet-metal-fundamentals.md`
- `references/15-materials-reference.md`
- `references/sheet-metal-formulas.md`

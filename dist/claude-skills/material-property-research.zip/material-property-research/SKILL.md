---
name: material-property-research
description: Look up and cite material properties and grade equivalences with source and condition, never from memory alone. Use for malzeme özellikleri, DC01/S235/304/316/5754 karşılaştırma, yoğunluk, mekanik değerler.
---
# Engineering Material Property Research
## Workflow
1. Identify exact material designation, temper/condition, product form, and applicable standard.
2. Define required properties: density, yield strength, tensile strength, elastic modulus, thermal data, etc.
3. Prefer primary standards, manufacturer datasheets, and recognized technical databases; record source and date.
4. Compare multiple sources and explain differences caused by alloy, temper, product form, or test condition.
5. Normalize units and avoid mixing values from different conditions.
6. For weight calculations, explicitly state the density used and its source; if only an approximate density is available, label the result accordingly.
7. Do not substitute a similar alloy or temper without disclosure.

## Output
Return a property table, exact material designation, sources, unit conversions, uncertainty notes, and recommended value for the stated calculation.

## Knowledge to load
Reference files are bundled in `references/`.
- `references/15-materials-reference.md`

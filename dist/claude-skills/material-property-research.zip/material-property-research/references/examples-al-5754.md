# Example: 5754 aluminium weight research
Do not answer only "aluminium density ≈ 2.7 g/cm³" when the user's priority is accurate mass.

Required output: exact designation/condition if known, density source(s), units, chosen value, calculation method, and uncertainty. If the requested product form or temper is unknown, say that the value is being treated as an engineering estimate rather than a certified material value.

---
name: metrology-inspection-planning
description: Turn critical drawing requirements into measurable inspection characteristics, datum setups and prototype/production checks.
---
# Metrology and Inspection Planning

## Trigger
Use when deciding how a dimension/GD&T item will be measured or preparing an inspection/FAI plan.

## Workflow
1. Identify function-critical characteristics.
2. Define the drawing datum/measurement setup.
3. Select a realistic measurement method and note flexible-part restraint.
4. State frequency/recording/reaction expectations from project quality rules.
5. Verify measurement capability before tightening tolerances.

## Knowledge to load
- `references/26-metrology-inspection-and-quality-planning.md`
- `references/06-technical-drawing.md`
- `references/07-gdt-and-tolerancing.md`

## Output discipline
- Label supplied, calculated, source-backed, assumed, estimated and unknown information.
- Do not invent manufacturer, shop or certification values.
- End with the smallest useful next verification/action.

---
name: manufacturing-process-selection
description: Select and review manufacturing routes for mechanical and sheet-metal parts using quantity, material, tolerance, finish, tooling and assembly constraints. Focuses on DFMA and supplier capability.
---
# Manufacturing Process Selection

## Trigger
Use when deciding laser/turret/form/weld/hardware/finish/assembly routes or simplifying a design for manufacture.

## Workflow
1. Capture quantity, material/thickness, finish, tolerances and critical features.
2. Map each feature to an operation and setup.
3. Identify special tooling, secondary operations and inspection bottlenecks.
4. Look for part commonization, locator features and service-friendly joining.
5. Compare feasible routes without declaring a best option until priorities are known.
6. Feed route assumptions to cost and drawing/release skills.

## Knowledge to load
- `references/19-manufacturing-process-selection-and-dfma.md`
- `references/01-sheet-metal-fundamentals.md`
- `references/14-welding-fasteners-finishing.md`
- `references/12-cost-analysis.md`

## Output discipline
- Distinguish facts, calculations, practice, assumptions, estimates and unknowns.
- Do not upgrade a draft analysis into a certification or release claim.
- Prefer a concrete next action over generic advice.

---
name: solidworks-macro-generator
description: Generate cautious SolidWorks API macros (VBA) with read-first design, null checks, no invented API members and a test-on-copy protocol. Use for SolidWorks makro, otomasyon, özel özellik, toplu işlem.
---
# SolidWorks Macro Generator
## Workflow
1. Convert the request into inputs, actions, outputs, and failure cases.
2. Identify Part, Assembly, Drawing, and configuration context.
3. Choose the smallest API surface needed.
4. Generate code with clear names and error handling.
5. Explain how to run it.
6. Provide a small test procedure before production use.
7. Mark version-sensitive API calls for documentation verification.
## Rules
- Never claim an unverified API member exists.
- Do not hide destructive operations.
- Preserve the user's intent during debugging and isolate the failing operation.

## Knowledge to load
Reference files are bundled in `references/`.
- `references/13-solidworks-macros-api.md`
- `references/03-solidworks-sheet-metal.md`

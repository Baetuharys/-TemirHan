---
name: visual-generation
description: Orchestrate visual generation tasks: choose between prompt engineering, editing, reference analysis and engineering visualization, and verify the result against invariants. Use for görsel üretim, kapak/illüstrasyon, teknik görsel iş akışı.
---

# Visual Generation Orchestrator

## Routing
- Yeni görsel → image-prompt-engineering
- Mevcut görsel düzenleme → image-editing
- Çoklu referans → reference-image-analysis + image-prompt-engineering
- CAD/teknik çizim/sketch → engineering-visualization
- İterasyon → önceki prompt + değişiklik listesi + invariant kontrolü

## Genel çıktı
Amaç, referans rolleri, üretim promptu, korunacaklar, kaçınılacaklar ve doğrulama maddeleri.
